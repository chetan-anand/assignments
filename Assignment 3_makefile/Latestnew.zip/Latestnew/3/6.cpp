#include<iostream>
using namespace std;
int main()
{
	cout << "Inside 6."<< endl;
	return 0;
}
