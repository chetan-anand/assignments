#include<stdio.h>

int main()
{
	printf("Inside 1.\n");
	return 0;
}