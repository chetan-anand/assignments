#include<stdio.h>

int main()
{
	printf("Inside 3.\n");
	return 0;
}