#include<iostream>
using namespace std;
int main()
{
	cout << "Inside 4."<< endl;
	return 0;
}
