#include<iostream>
using namespace std;
int main()
{
	cout << "Inside 5."<< endl;
	return 0;
}
