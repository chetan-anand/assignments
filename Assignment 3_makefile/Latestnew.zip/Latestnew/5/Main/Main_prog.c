#include<stdio.h>



int main()
{
	printf("Inside Main_prog\n" ); 
	
	return 0;
}