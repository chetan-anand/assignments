#include<stdio.h>

int main()
{
	printf("Inside Add_Three_numbers.\n");
	return 0;
}