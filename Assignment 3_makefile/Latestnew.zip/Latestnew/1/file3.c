#include<stdio.h>

#include "function.h"

void file3(){

	printf("Inside file3\n");
	
}
