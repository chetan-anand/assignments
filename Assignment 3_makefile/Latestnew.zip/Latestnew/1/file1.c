#include<stdio.h>

#include "function.h"

void file1(){

	printf("Inside file1\n");
	
}
