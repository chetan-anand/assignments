#include<stdio.h>

#include "function.h"

int main()
{

	file1();
	file2();
	file3();
	return 0;

}
