#include<stdio.h>

#include "function.h"

void file2(){

	printf("Inside file2\n");
	
}
